<?php

if ($ac=="gioithieu") 
			include ROOT."/module/info/gioithieu.php";
if ($ac=="lienhe") 
			include ROOT."/module/info/lienhe.php";
?>