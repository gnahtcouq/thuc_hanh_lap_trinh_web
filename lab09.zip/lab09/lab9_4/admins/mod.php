<?php
$mod = getIndex("mod","home");
			
if ($mod=="book")
	include "module/book/index.php";

?>