<a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;
<a href="#">Tin tức</a>&nbsp;&nbsp;&nbsp;
<a href="#">Sản Phẩm</a>&nbsp;&nbsp;&nbsp;
<a href="index.php?mod=cart">Giỏ hàng (<span id="cart_sumary"><?php echo  $cart->getNumItem();
?></span>)</a>&nbsp;