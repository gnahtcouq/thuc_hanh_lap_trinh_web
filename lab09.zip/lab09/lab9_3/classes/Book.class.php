<?php
class Book extends Db{
	public function getRand($n)
	{
		$sql="select book_id, book_name, img from book order by rand() limit 0, $n ";
		return $this->exeQuery($sql);	
	}
	
	
	public function delete($book_id)
	{
			
	}
	
	public function getDetail($book_id)
	{
		
					
		
	}

}
?>