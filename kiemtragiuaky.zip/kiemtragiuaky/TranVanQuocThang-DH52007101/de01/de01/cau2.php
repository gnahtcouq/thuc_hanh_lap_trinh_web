<?php 
$giohang=[
    ['ma'=>1, 'ten'=>'Iphone 15', 'soluong'=>1, 'dongia'=>28000000, 'img'=>'iphone.jpg'],
    ['ma'=>3, 'ten'=>'Samsung', 'soluong'=>2, 'dongia'=>30990000,  'img'=>'samsung.jpg'],
    ['ma'=>2, 'ten'=>'Man Hinh ', 'soluong'=>2, 'dongia'=>2100000, 'img'=>'manhinh.jpg'],
    ['ma'=>4, 'ten'=>'Mouse', 'soluong'=>3, 'dongia'=>1900000, 'img'=>'mouse.jpg'],
];
$tongTien = 0;
echo"<table border=1>";
    echo"<tr><th>STT</th><th>Tên SP</th><th>Hình</th><th>Số lượng</th><th>Thành tiền</th><th>Đơn giá</th></tr>";
    foreach ($giohang as $key => $sanpham) {
        $stt = $key + 1;
        $tenSP = $sanpham['ten'];
        $hinh = "hinh/" . strtolower(str_replace(' ', '', $tenSP)) . ".jpg";
        $soLuong = $sanpham['soluong'];
        $donGia = $sanpham['dongia'];
        $thanhTien = $soLuong * $donGia;
        
        echo "<tr>";
        echo "<td>$stt</td>";
        echo "<td>$tenSP</td>";
        echo "<td><img src='$hinh' alt='Hình sản phẩm' style='width: 50px; height: 50px;'></td>";
        echo "<td>$soLuong</td>";
        echo "<td>" . number_format($donGia) . " VND</td>";
        echo "<td>" . number_format($thanhTien) . " VND</td>";
        
        $tongTien += $thanhTien;
    }
    echo "</tr>";
    echo "<tr>";
    echo "<td colspan='12'>Tổng Tiền:" . number_format($tongTien) . "</td>";
    echo "</tr>";
    echo"</table>";
    ?>